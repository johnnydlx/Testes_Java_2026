# Aula 05 - Desafio

Projeto Maven com JUnit 5 para o desafio da Calculadora de Frete.

## Executar
```bash
mvn test
```
