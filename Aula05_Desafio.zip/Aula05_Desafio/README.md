# Aula 05 - Desafio

Projeto Maven com a solução do desafio de testes parametrizados da Calculadora de Frete.

No Windows, execute `mvnw.cmd test` para testar e `mvnw.cmd exec:java` para abrir a `Main`.
