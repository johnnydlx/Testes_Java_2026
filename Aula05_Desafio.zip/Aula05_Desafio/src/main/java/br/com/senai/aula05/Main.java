package br.com.senai.aula05;

public class Main {
    public static void main(String[] args) {
        double pesoKg = 3.0;
        System.out.printf("Peso: %.2f kg%n", pesoKg);
        System.out.printf("Frete comum: R$ %.2f%n", CalculadoraFrete.calcular(pesoKg, false));
        System.out.printf("Frete expresso: R$ %.2f%n", CalculadoraFrete.calcular(pesoKg, true));
    }
}
