package br.com.senai.aula05;

public class CalculadoraFrete {

    public double calcular(double pesoKg, boolean expressa) {
        if (pesoKg <= 0) {
            throw new IllegalArgumentException("O peso deve ser maior que zero.");
        }

        double valor = 8.0 + (2.0 * pesoKg);

        if (expressa) {
            valor *= 1.5;
        }

        return valor;
    }
}
