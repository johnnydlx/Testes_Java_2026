package br.com.senai.aula05;

public class CalculadoraFrete {
    private CalculadoraFrete() {
    }

    public static double calcular(double pesoKg, boolean entregaExpressa) {
        if (pesoKg <= 0) {
            throw new IllegalArgumentException("O peso deve ser maior que zero.");
        }
        double valor = 8.0 + (pesoKg * 2.0);
        return entregaExpressa ? valor * 1.5 : valor;
    }
}
