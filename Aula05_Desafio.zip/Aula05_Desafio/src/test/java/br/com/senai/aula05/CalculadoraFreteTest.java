package br.com.senai.aula05;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraFreteTest {

    private final CalculadoraFrete calculadora = new CalculadoraFrete();

    @ParameterizedTest(name = "peso={0}kg, expressa={1} => R$ {2}")
    @CsvSource({
            "1.0, false, 10.0",
            "2.0, false, 12.0",
            "5.0, false, 18.0",
            "1.0, true, 15.0",
            "2.0, true, 18.0",
            "5.0, true, 27.0"
    })
    @DisplayName("Deve calcular o frete para vários pesos e modalidades")
    void deveCalcularFrete(double pesoKg, boolean expressa, double esperado) {
        // Arrange: dados recebidos pelo CsvSource
        // Act
        double resultado = calculadora.calcular(pesoKg, expressa);

        // Assert
        assertEquals(esperado, resultado, 0.001);
    }

    @ParameterizedTest
    @ValueSource(doubles = {0.0, -0.1, -1.0, -10.0})
    @DisplayName("Deve rejeitar peso zero ou negativo")
    void deveLancarExcecaoParaPesoInvalido(double peso) {
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> calculadora.calcular(peso, false)
        );

        assertEquals("O peso deve ser maior que zero.", excecao.getMessage());
    }

    @Test
    @DisplayName("Frete expresso deve custar 50% a mais")
    void freteExpressoDeveCustarCinquentaPorCentoAMais() {
        double comum = calculadora.calcular(3.0, false);
        double expresso = calculadora.calcular(3.0, true);

        assertAll(
                () -> assertEquals(14.0, comum, 0.001),
                () -> assertEquals(21.0, expresso, 0.001),
                () -> assertEquals(comum * 1.5, expresso, 0.001)
        );
    }
}
