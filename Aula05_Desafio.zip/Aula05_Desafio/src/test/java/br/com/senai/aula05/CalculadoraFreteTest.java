package br.com.senai.aula05;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CalculadoraFreteTest {
    @ParameterizedTest(name = "peso={0}kg, expressa={1} => R$ {2}")
    @CsvSource({"1.0, false, 10.0", "2.0, false, 12.0", "5.0, false, 18.0", "1.0, true, 15.0", "2.0, true, 18.0", "5.0, true, 27.0", "0.01, false, 8.02"})
    @DisplayName("Deve calcular o frete para vários pesos e modalidades")
    void deveCalcularFrete(double pesoKg, boolean expressa, double esperado) {
        assertEquals(esperado, CalculadoraFrete.calcular(pesoKg, expressa), 0.001);
    }

    @ParameterizedTest
    @ValueSource(doubles = {0.0, -0.1, -1.0, -10.0})
    @DisplayName("Deve rejeitar peso zero ou negativo")
    void deveLancarExcecaoParaPesoInvalido(double peso) {
        IllegalArgumentException erro = assertThrows(IllegalArgumentException.class,
                () -> CalculadoraFrete.calcular(peso, false));
        assertEquals("O peso deve ser maior que zero.", erro.getMessage());
    }
}
