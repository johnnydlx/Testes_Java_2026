# Aula 06 - Desafio

Projeto Maven com JUnit 5, organização com `@DisplayName`, `@Nested` e `@Tag`,
além de revisão de herança e polimorfismo.

## Executar
```bash
mvn test
```
