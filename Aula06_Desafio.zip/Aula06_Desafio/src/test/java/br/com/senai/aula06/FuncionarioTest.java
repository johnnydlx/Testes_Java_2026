package br.com.senai.aula06;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Suíte de testes de Funcionários")
class FuncionarioTest {

    @Nested
    @DisplayName("Funcionário comum")
    class FuncionarioComumTests {

        @Test
        @Tag("salario")
        @DisplayName("deve retornar o salário base")
        void deveRetornarSalarioBase() {
            Funcionario funcionario = new FuncionarioComum("Ana", 2500.00);

            assertAll(
                    () -> assertEquals("Ana", funcionario.getNome()),
                    () -> assertEquals(2500.00, funcionario.calcularSalario(), 0.001)
            );
        }
    }

    @Nested
    @DisplayName("Gerente")
    class GerenteTests {

        @Test
        @Tag("salario")
        @DisplayName("deve somar bônus ao salário base")
        void deveSomarBonus() {
            Gerente gerente = new Gerente("Carlos", 5000.00, 1500.00);

            assertAll(
                    () -> assertEquals(1500.00, gerente.getBonus(), 0.001),
                    () -> assertEquals(6500.00, gerente.calcularSalario(), 0.001)
            );
        }
    }

    @Nested
    @DisplayName("Polimorfismo")
    class PolimorfismoTests {

        @Test
        @Tag("poo")
        @DisplayName("deve calcular salários conforme o tipo real do objeto")
        void deveAplicarPolimorfismo() {
            List<Funcionario> funcionarios = List.of(
                    new FuncionarioComum("Bia", 2000.00),
                    new Gerente("João", 4000.00, 1000.00)
            );

            assertAll(
                    () -> assertEquals(2000.00, funcionarios.get(0).calcularSalario(), 0.001),
                    () -> assertEquals(5000.00, funcionarios.get(1).calcularSalario(), 0.001)
            );
        }
    }

    @Nested
    @DisplayName("Validações")
    class ValidacoesTests {

        @Test
        @Tag("validacao")
        @DisplayName("deve rejeitar nome vazio")
        void deveRejeitarNomeVazio() {
            assertThrows(IllegalArgumentException.class,
                    () -> new FuncionarioComum(" ", 2000.00));
        }

        @Test
        @Tag("validacao")
        @DisplayName("deve rejeitar salário inválido")
        void deveRejeitarSalarioInvalido() {
            assertThrows(IllegalArgumentException.class,
                    () -> new FuncionarioComum("Ana", 0));
        }

        @Test
        @Tag("validacao")
        @DisplayName("deve rejeitar bônus negativo")
        void deveRejeitarBonusNegativo() {
            assertThrows(IllegalArgumentException.class,
                    () -> new Gerente("Carlos", 5000.00, -1));
        }
    }
}
