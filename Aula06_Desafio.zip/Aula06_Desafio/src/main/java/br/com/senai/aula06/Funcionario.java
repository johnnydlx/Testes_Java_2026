package br.com.senai.aula06;

public abstract class Funcionario {
    private final String nome;
    private final double salarioBase;

    protected Funcionario(String nome, double salarioBase) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }
        if (salarioBase <= 0) {
            throw new IllegalArgumentException("Salário base deve ser maior que zero.");
        }
        this.nome = nome;
        this.salarioBase = salarioBase;
    }

    public String getNome() {
        return nome;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public abstract double calcularSalario();
}
