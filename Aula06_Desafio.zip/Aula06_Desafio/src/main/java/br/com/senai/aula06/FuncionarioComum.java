package br.com.senai.aula06;

public class FuncionarioComum extends Funcionario {

    public FuncionarioComum(String nome, double salarioBase) {
        super(nome, salarioBase);
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase();
    }
}
