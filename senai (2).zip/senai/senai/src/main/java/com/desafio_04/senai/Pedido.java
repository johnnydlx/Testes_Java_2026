package com.desafio_04.senai;

public class Pedido {

    private String cliente;
    private double valor;
    private boolean pago;

    public Pedido(String cliente, double valor) {

        if (cliente == null || cliente.isBlank()) {
            throw new IllegalArgumentException(
                    "O cliente é obrigatório."
            );
        }

        if (valor <= 0) {
            throw new IllegalArgumentException(
                    "O valor do pedido deve ser maior que zero."
            );
        }

        this.cliente = cliente;
        this.valor = valor;
        this.pago = false;
    }

    public void pagar() {
        pago = true;
    }

    public String getCliente() {
        return cliente;
    }

    public double getValor() {
        return valor;
    }

    public boolean isPago() {
        return pago;
    }
}