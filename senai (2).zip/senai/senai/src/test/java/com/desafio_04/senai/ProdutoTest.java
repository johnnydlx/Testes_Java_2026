package com.desafio_04.senai;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProdutoTest {

    @Test
    void calcularValorEmEstoqueDeveMultiplicarPrecoPelaQuantidade() {

        Produto produto = new Produto("Teclado", 100.50, 3);


        double obtido = produto.calcularValorEmEstoque();


        assertEquals(301.50, obtido, 0.001);
    }

    @Test
    void temEstoqueDeveRetornarTrueQuandoHouverProdutos() {

        Produto produto = new Produto("Mouse", 50.00, 5);


        boolean resultado = produto.temEstoque();


        assertTrue(resultado);
    }

    @Test
    void temEstoqueDeveRetornarFalseQuandoEstoqueForZero() {

        Produto produto = new Produto("Mouse", 50.00, 0);


        boolean resultado = produto.temEstoque();


        assertFalse(resultado);
    }

    @Test
    void deveRejeitarPrecoIgualAZero() {

        String mensagemEsperada = "O preço deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Produto("Mouse", 0, 10)
        );


        assertEquals(mensagemEsperada, excecao.getMessage());
    }

    @Test
    void deveRejeitarPrecoNegativo() {

        String mensagemEsperada = "O preço deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Produto("Mouse", -10, 10)
        );


        assertEquals(mensagemEsperada, excecao.getMessage());
    }

    @Test
    void deveRejeitarQuantidadeInicialNegativa() {

        String mensagemEsperada = "O estoque não pode ser negativo.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Produto("Mouse", 50, -1)
        );


        assertEquals(mensagemEsperada, excecao.getMessage());
    }
}