package com.desafio_04.senai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
