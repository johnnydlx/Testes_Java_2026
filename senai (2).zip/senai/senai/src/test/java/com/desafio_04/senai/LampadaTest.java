package com.desafio_04.senai;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LampadaTest {

    @Test
    void lampadaRecemCriadaDeveEstarDesligada() {

        Lampada lampada = new Lampada("Quarto");


        boolean estado = lampada.isLigada();


        assertFalse(estado);
    }

    @Test
    void lampadaRecemCriadaDeveTerIntensidadeZero() {

        Lampada lampada = new Lampada("Quarto");


        int intensidade = lampada.getIntensidade();


        assertEquals(0, intensidade);
    }

    @Test
    void ligarDeveAlterarEstadoDaLampadaParaLigada() {

        Lampada lampada = new Lampada("Quarto");


        lampada.ligar();

        assertTrue(lampada.isLigada());
    }

    @Test
    void ligarDeveAlterarIntensidadeParaCem() {

        Lampada lampada = new Lampada("Quarto");


        lampada.ligar();


        assertEquals(100, lampada.getIntensidade());
    }

    @Test
    void desligarDeveRestaurarEstadoEIntensidadeIniciais() {

        Lampada lampada = new Lampada("Quarto");
        lampada.ligar();


        lampada.desligar();


        assertAll(
                () -> assertFalse(lampada.isLigada()),
                () -> assertEquals(0, lampada.getIntensidade())
        );
    }
}