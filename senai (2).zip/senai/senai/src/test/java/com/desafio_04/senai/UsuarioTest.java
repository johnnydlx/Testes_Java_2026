package com.desafio_04.senai;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    @Test
    void usuarioRecemCriadoDeveTerTelefoneNulo() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");


        String telefone = usuario.getTelefone();


        assertNull(telefone);
    }

    @Test
    void usuarioRecemCriadoDeveEstarAtivo() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");

        boolean ativo = usuario.isAtivo();


        assertTrue(ativo);
    }

    @Test
    void definirTelefoneDeveArmazenarTelefoneInformado() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");
        String telefone = "47999999999";


        usuario.definirTelefone(telefone);


        assertNotNull(usuario.getTelefone());
    }

    @Test
    void definirTelefoneDeveArmazenarTelefoneCorretamente() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");
        String telefone = "47999999999";


        usuario.definirTelefone(telefone);


        assertEquals(telefone, usuario.getTelefone());
    }

    @Test
    void telefoneNuloDeveLancarExcecao() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> usuario.definirTelefone(null)
        );


        assertEquals(
                "O telefone é obrigatório.",
                excecao.getMessage()
        );
    }

    @Test
    void telefoneEmBrancoDeveLancarExcecao() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> usuario.definirTelefone("   ")
        );


        assertEquals(
                "O telefone é obrigatório.",
                excecao.getMessage()
        );
    }

    @Test
    void desativarDeveAlterarEstadoParaInativo() {

        Usuario usuario = new Usuario("Johnny", "johnny@email.com");


        usuario.desativar();


        assertFalse(usuario.isAtivo());
    }

    @Test
    void usuarioRecemCriadoDeveTerEstadoInicialCorreto() {

        Usuario usuario = new Usuario(
                "Johnny",
                "johnny@email.com"
        );



        assertAll(
                () -> assertEquals("Johnny", usuario.getNome()),
                () -> assertEquals(
                        "johnny@email.com",
                        usuario.getEmail()
                ),
                () -> assertNull(usuario.getTelefone()),
                () -> assertTrue(usuario.isAtivo())
        );
    }
}