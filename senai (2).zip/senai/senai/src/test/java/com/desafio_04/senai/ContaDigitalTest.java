package com.desafio_04.senai;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaDigitalTest {

    @Test
    void contaRecemCriadaDeveTerSaldoZero() {

        ContaDigital conta = new ContaDigital("Johnny");


        double saldo = conta.getSaldo();


        assertEquals(0, saldo, 0.001);
    }

    @Test
    void depositoDeveAumentarOSaldo() {

        ContaDigital conta = new ContaDigital("Johnny");


        conta.depositar(500);


        assertEquals(500, conta.getSaldo(), 0.001);
    }

    @Test
    void saqueValidoDeveReduzirOSaldo() {

        ContaDigital conta = new ContaDigital("Johnny");
        conta.depositar(500);


        conta.sacar(200);

        assertEquals(300, conta.getSaldo(), 0.001);
    }

    @Test
    void depositoZeroDeveLancarExcecao() {

        ContaDigital conta = new ContaDigital("Johnny");


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> conta.depositar(0)
        );


        assertEquals(
                "O depósito deve ser maior que zero.",
                excecao.getMessage()
        );
    }

    @Test
    void depositoNegativoDeveLancarExcecao() {

        ContaDigital conta = new ContaDigital("Johnny");


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> conta.depositar(-100)
        );


        assertEquals(
                "O depósito deve ser maior que zero.",
                excecao.getMessage()
        );
    }

    @Test
    void saqueZeroDeveLancarExcecao() {

        ContaDigital conta = new ContaDigital("Johnny");
        conta.depositar(500);


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> conta.sacar(0)
        );


        assertEquals(
                "O saque deve ser maior que zero.",
                excecao.getMessage()
        );
    }

    @Test
    void saqueNegativoDeveLancarExcecao() {

        ContaDigital conta = new ContaDigital("Johnny");
        conta.depositar(500);


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> conta.sacar(-100)
        );

        assertEquals(
                "O saque deve ser maior que zero.",
                excecao.getMessage()
        );
    }

    @Test
    void saqueMaiorQueSaldoDeveLancarExcecao() {

        ContaDigital conta = new ContaDigital("Johnny");
        conta.depositar(500);


        IllegalStateException excecao = assertThrows(
                IllegalStateException.class,
                () -> conta.sacar(600)
        );


        assertAll(
                () -> assertEquals(
                        "Saldo insuficiente.",
                        excecao.getMessage()
                ),
                () -> assertEquals(
                        500,
                        conta.getSaldo(),
                        0.001
                )
        );
    }

    @Test
    void operacaoRejeitadaNaoDeveAlterarOSaldo() {

        ContaDigital conta = new ContaDigital("Johnny");
        conta.depositar(500);


        assertThrows(
                IllegalStateException.class,
                () -> conta.sacar(1000)
        );


        assertEquals(500, conta.getSaldo(), 0.001);
    }
}