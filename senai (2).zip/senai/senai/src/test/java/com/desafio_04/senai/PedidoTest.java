package com.desafio_04.senai;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PedidoTest {

    @Test
    void deveRetornarValorCorretoDoPedido() {
        // Arrange
        Pedido pedido = new Pedido("Johnny", 150.50);


        double valorObtido = pedido.getValor();


        assertEquals(150.50, valorObtido, 0.001);
    }

    @Test
    void pedidoRecemCriadoDeveEstarNaoPago() {

        Pedido pedido = new Pedido("Johnny", 150.50);


        boolean pago = pedido.isPago();


        assertFalse(pago);
    }

    @Test
    void pagarDeveAlterarEstadoDoPedidoParaPago() {

        Pedido pedido = new Pedido("Johnny", 150.50);


        pedido.pagar();


        assertTrue(pedido.isPago());
    }

    @Test
    void deveLancarExcecaoQuandoClienteForNulo() {

        String mensagemEsperada = "O cliente é obrigatório.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Pedido(null, 150.50)
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void deveLancarExcecaoQuandoValorForZero() {

        String mensagemEsperada =
                "O valor do pedido deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Pedido("Johnny", 0)
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void deveLancarExcecaoQuandoValorForNegativo() {

        String mensagemEsperada =
                "O valor do pedido deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new Pedido("Johnny", -50)
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void pedidoRecemCriadoDevePossuirEstadoInicialCorreto() {

        Pedido pedido = new Pedido("Johnny", 250.00);


        assertAll(
                () -> assertEquals(
                        "Johnny",
                        pedido.getCliente()
                ),
                () -> assertEquals(
                        250.00,
                        pedido.getValor(),
                        0.001
                ),
                () -> assertFalse(
                        pedido.isPago()
                )
        );
    }
}