package com.desafio_04.senai;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReservaHotelTest {

    @Test
    void reservaRecemCriadaDeveTerEstadoInicialCompletoCorreto() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );

        assertAll(
                () -> assertEquals(
                        "Johnny",
                        reserva.getHospede()
                ),
                () -> assertEquals(
                        3,
                        reserva.getQuantidadeDiarias()
                ),
                () -> assertEquals(
                        250.00,
                        reserva.getValorDiaria(),
                        0.001
                ),
                () -> assertFalse(reserva.isConfirmada()),
                () -> assertNull(reserva.getCodigoConfirmacao())
        );
    }

    @Test
    void calcularTotalDeveMultiplicarDiariasPeloValorDaDiaria() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );


        double total = reserva.calcularTotal();


        assertEquals(750.00, total, 0.001);
    }

    @Test
    void confirmarDeveAlterarEstadoEArmazenarCodigo() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );
        String codigo = "ABC123";


        reserva.confirmar(codigo);


        assertAll(
                () -> assertTrue(reserva.isConfirmada()),
                () -> assertNotNull(
                        reserva.getCodigoConfirmacao()
                ),
                () -> assertEquals(
                        codigo,
                        reserva.getCodigoConfirmacao()
                )
        );
    }

    @Test
    void hospedeNuloDeveLancarExcecao() {

        String mensagemEsperada = "O hóspede é obrigatório.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        null,
                        3,
                        250.00
                )
        );

        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void hospedeEmBrancoDeveLancarExcecao() {

        String mensagemEsperada = "O hóspede é obrigatório.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        "   ",
                        3,
                        250.00
                )
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void quantidadeDeDiariasZeroDeveLancarExcecao() {

        String mensagemEsperada =
                "A quantidade de diárias deve ser maior que zero.";

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        "Johnny",
                        0,
                        250.00
                )
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void quantidadeDeDiariasNegativaDeveLancarExcecao() {

        String mensagemEsperada =
                "A quantidade de diárias deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        "Johnny",
                        -1,
                        250.00
                )
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void valorDaDiariaZeroDeveLancarExcecao() {

        String mensagemEsperada =
                "O valor da diária deve ser maior que zero.";


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        "Johnny",
                        3,
                        0
                )
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void valorDaDiariaNegativoDeveLancarExcecao() {

        String mensagemEsperada =
                "O valor da diária deve ser maior que zero.";

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> new ReservaHotel(
                        "Johnny",
                        3,
                        -250.00
                )
        );


        assertEquals(
                mensagemEsperada,
                excecao.getMessage()
        );
    }

    @Test
    void codigoNuloDeveLancarExcecao() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> reserva.confirmar(null)
        );


        assertEquals(
                "O código de confirmação é obrigatório.",
                excecao.getMessage()
        );
    }

    @Test
    void codigoEmBrancoDeveLancarExcecao() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> reserva.confirmar("   ")
        );


        assertEquals(
                "O código de confirmação é obrigatório.",
                excecao.getMessage()
        );
    }

    @Test
    void segundaConfirmacaoDeveLancarExcecao() {

        ReservaHotel reserva = new ReservaHotel(
                "Johnny",
                3,
                250.00
        );

        reserva.confirmar("ABC123");


        IllegalStateException excecao = assertThrows(
                IllegalStateException.class,
                () -> reserva.confirmar("XYZ789")
        );


        assertEquals(
                "A reserva já está confirmada.",
                excecao.getMessage()
        );
    }
}