package com.example.demo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CalculadoraFreteTest {

    @ParameterizedTest(
            name = "peso= 0 kg, expressa= 1, esperado=R$ 2"
    )
    @CsvSource({
            "0.01, false,  8.02",
            "1.00, false, 10.00",
            "5.00, false, 18.00",
            "1.00, true,  15.00",
            "5.00, true,  27.00",
            "0.01, true,  12.03"
    })
    void calcularDeveRetornarFreteCorreto(
            double peso,
            boolean entregaExpressa,
            double esperado) {

        double obtido = CalculadoraFrete.calcular(peso, entregaExpressa);

        assertEquals(esperado, obtido, 0.001);
    }

    @ParameterizedTest(
            name = "peso inválido= 0 deve lançar aviso"
    )
    @ValueSource(doubles = {0.0, -0.01, -1.0, -10.0})
    void pesoZeroOuNegativoDeveLancarExcecao(double peso) {

        boolean entregaExpressa = false;


        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraFrete.calcular(peso, entregaExpressa)
        );

        assertEquals(
                "O peso deve ser maior que zero.",
                excecao.getMessage()
        );
    }
}
