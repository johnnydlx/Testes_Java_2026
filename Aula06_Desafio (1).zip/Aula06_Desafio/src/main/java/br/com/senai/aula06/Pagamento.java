package br.com.senai.aula06;

public abstract class Pagamento {
    protected final double valor;

    protected Pagamento(double valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("O valor deve ser maior que zero.");
        }
        this.valor = valor;
    }

    public abstract double calcularTaxa();
}
