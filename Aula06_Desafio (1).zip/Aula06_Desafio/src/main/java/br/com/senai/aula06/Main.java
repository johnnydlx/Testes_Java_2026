package br.com.senai.aula06;

public class Main {
    public static void main(String[] args) {
        Pagamento pix = new PagamentoPix(200.0);
        Pagamento cartao = new PagamentoCartao(200.0);
        System.out.printf("Taxa do Pix: R$ %.2f%n", pix.calcularTaxa());
        System.out.printf("Taxa do cartão: R$ %.2f%n", cartao.calcularTaxa());
    }
}
