package br.com.senai.aula06;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes da hierarquia de pagamentos")
class PagamentoTest {
    @Nested @DisplayName("Pagamento via Pix")
    class PixTests {
        @Test @DisplayName("deve possuir taxa zero")
        void devePossuirTaxaZero() {
            Pagamento pagamento = new PagamentoPix(100.0);
            assertEquals(0.0, pagamento.calcularTaxa(), 0.001);
        }

        @Test @DisplayName("deve rejeitar valor inválido")
        void deveRejeitarValorInvalido() {
            IllegalArgumentException erro = assertThrows(IllegalArgumentException.class, () -> new PagamentoPix(0));
            assertEquals("O valor deve ser maior que zero.", erro.getMessage());
        }
    }

    @Nested @Tag("cartao") @DisplayName("Pagamento via cartão")
    class CartaoTests {
        @Test @DisplayName("deve calcular taxa de 2,5%")
        void deveCalcularTaxa() {
            Pagamento pagamento = new PagamentoCartao(200.0);
            assertEquals(5.0, pagamento.calcularTaxa(), 0.001);
        }

        @Test @DisplayName("deve rejeitar valor inválido")
        void deveRejeitarValorInvalido() {
            assertThrows(IllegalArgumentException.class, () -> new PagamentoCartao(-1));
        }
    }

    @Nested @DisplayName("Polimorfismo")
    class PolimorfismoTests {
        @Test @DisplayName("deve executar a taxa correta conforme o tipo real")
        void deveAplicarPolimorfismo() {
            Pagamento pix = new PagamentoPix(200.0);
            Pagamento cartao = new PagamentoCartao(200.0);
            assertAll(
                    () -> assertEquals(0.0, pix.calcularTaxa(), 0.001),
                    () -> assertEquals(5.0, cartao.calcularTaxa(), 0.001)
            );
        }
    }
}
