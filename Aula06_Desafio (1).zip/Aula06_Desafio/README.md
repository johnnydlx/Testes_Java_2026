# Aula 06 - Desafio

Projeto Maven com a hierarquia de pagamentos, herança, polimorfismo e testes com `@DisplayName`, `@Nested`, `@Tag` e `assertAll`.

No Windows, execute `mvnw.cmd test` para testar e `mvnw.cmd exec:java` para abrir a `Main`.
